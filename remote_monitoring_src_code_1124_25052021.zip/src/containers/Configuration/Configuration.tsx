import React, { Component } from 'react';

class Configuration extends Component {
  render() {
    return (
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: '20%'}}>
        <div style={{fontSize: '3rem', fontWeight: 'bolder', color: '#b0a9a9'}}>Remote Monitoring Configuration</div>
        <div style={{fontSize: '2rem', fontWeight: 'bold', color: '#b0a9a9'}}>(Under Construction)</div>
      </div>
    )
  }
}

export default Configuration;
