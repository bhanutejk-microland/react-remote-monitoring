declare module "authOptions";
