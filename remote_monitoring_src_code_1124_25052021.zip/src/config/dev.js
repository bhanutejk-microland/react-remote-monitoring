// Don't commit
module.exports = {
  API_BASE_URL: "http://localhost:3000/",
  AZURE_MAP_SUB_KEY: "eRfXbpJ5fJxlVdzu_oDY70n_WVIvDscfNcdBm4NUc6o"
};
