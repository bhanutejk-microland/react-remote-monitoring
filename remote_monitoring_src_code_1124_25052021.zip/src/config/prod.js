module.exports = {
  API_BASE_URL: "https://remote-monitoring-api.azurewebsites.net/",
  AZURE_MAP_SUB_KEY: "eRfXbpJ5fJxlVdzu_oDY70n_WVIvDscfNcdBm4NUc6o"
};
