export interface DeviceListModel {
  deviceName: string;
  deviceType: string;
  status: string;
  lastConnect: string;
}
