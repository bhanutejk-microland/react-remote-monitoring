export interface AlertHeaderInfoModel {
  id: string;
  numeric: boolean;
  disablePadding: boolean;
  label: string;
}
