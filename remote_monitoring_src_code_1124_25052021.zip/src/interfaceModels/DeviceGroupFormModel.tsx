import { FormInputModel } from './FormInputModel';

export interface DeviceGroupFormModel {
  deviceGroupName: FormInputModel;
  deviceGroupId: FormInputModel;
  // createdAt: FormInputModel;
  // createdBy: FormInputModel;
}