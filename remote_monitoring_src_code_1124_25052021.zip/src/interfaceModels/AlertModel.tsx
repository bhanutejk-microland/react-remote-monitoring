export interface AlertModel {
  assetId: string;
  dateTime: string;
  status: string;
  type: string;
  summary: string;
}
