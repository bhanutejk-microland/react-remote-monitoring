import { TicketModel } from './TicketModel';

export interface FilterDateModel {
  fromDate : string;
  toDate : string;
}
