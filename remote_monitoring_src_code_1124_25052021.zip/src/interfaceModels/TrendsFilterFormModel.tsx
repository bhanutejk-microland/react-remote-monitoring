import { FormDropdownModel } from "./FormDropdownModel";

export interface TrendsFilterFormModel {
  timePeriod: FormDropdownModel;
}