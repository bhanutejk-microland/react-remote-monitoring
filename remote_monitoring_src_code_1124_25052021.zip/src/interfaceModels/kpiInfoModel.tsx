export interface kpiInfoModel {
  totalAssets: object;
  totalActive: object;
  totalTripped: object;
  totalInactive: object;
  totalCriticalAlerts: object;
  fletUptime: object;
}
