export interface RulesListModel {
  Name: string;
  Description: string;
  deviceGroup: string;
  Severity: string;
}
