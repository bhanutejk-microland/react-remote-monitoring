export interface TicketModel {
  ticketId: string;
  ticketDescription: string;
  createdBy: string;
  createdAt: Date;
  status: string;
}
