import { FormDropdownModel } from "./FormDropdownModel";

export interface AssetFilterFormModel {
  timePeriod: FormDropdownModel;
}