export interface predictionListModel {
  timestamp: number;
  head: number;
  speed: number;
  flow: number;
  torque: number;
  fault: string;
  faultProbability: number;
  noFaultProbability: number;
}
